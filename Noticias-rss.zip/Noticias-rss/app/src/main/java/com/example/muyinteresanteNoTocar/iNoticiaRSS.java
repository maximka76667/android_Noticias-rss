package com.example.muyinteresanteNoTocar;

import java.util.ArrayList;

public interface iNoticiaRSS {
	void onRecibeNoticiasRSS(ArrayList<NoticiaRSS> listaNoticias);
}
